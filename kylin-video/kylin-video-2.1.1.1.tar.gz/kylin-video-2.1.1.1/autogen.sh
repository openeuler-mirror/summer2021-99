#! /bin/sh
# Run this to generate all the initial makefiles, etc.

lrelease kylin-video.pro
