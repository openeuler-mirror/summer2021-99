<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="bo_CN">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../aboutdialog.ui" line="26"/>
        <location filename="../aboutdialog.ui" line="66"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="79"/>
        <source>Contributor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="131"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="88"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="192"/>
        <source>Kylin Video is developed on the basis of %1, is a graphical interface for %2 and %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="193"/>
        <source>Kylin Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="193"/>
        <source>Version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="194"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="195"/>
        <source>Playback engine:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="196"/>
        <source>Links:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="197"/>
        <source>Code website:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="198"/>
        <source>Developer&apos;s personal home page:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="232"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="232"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="232"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="475"/>
        <source>Choose a filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="477"/>
        <location filename="../smplayer/actionseditor.cpp" line="527"/>
        <source>Key files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="486"/>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="487"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="499"/>
        <location filename="../smplayer/actionseditor.cpp" line="533"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="500"/>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="526"/>
        <source>Choose a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/actionseditor.cpp" line="534"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioDelayDialog</name>
    <message>
        <location filename="../smplayer/audiodelaydialog.ui" line="26"/>
        <location filename="../smplayer/audiodelaydialog.ui" line="77"/>
        <source>Audio delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audiodelaydialog.ui" line="38"/>
        <location filename="../smplayer/audiodelaydialog.cpp" line="54"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audiodelaydialog.ui" line="51"/>
        <location filename="../smplayer/audiodelaydialog.cpp" line="59"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audiodelaydialog.ui" line="93"/>
        <source>Audio delay (in milliseconds):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="189"/>
        <source>Audio Equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="192"/>
        <location filename="../smplayer/audioequalizer.cpp" line="193"/>
        <location filename="../smplayer/audioequalizer.cpp" line="194"/>
        <location filename="../smplayer/audioequalizer.cpp" line="195"/>
        <location filename="../smplayer/audioequalizer.cpp" line="196"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="197"/>
        <location filename="../smplayer/audioequalizer.cpp" line="198"/>
        <location filename="../smplayer/audioequalizer.cpp" line="199"/>
        <location filename="../smplayer/audioequalizer.cpp" line="200"/>
        <location filename="../smplayer/audioequalizer.cpp" line="201"/>
        <source>%1 kHz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="203"/>
        <source>&amp;Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="204"/>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="205"/>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="206"/>
        <source>&amp;Set as default values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="207"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="212"/>
        <source>Flat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="213"/>
        <source>Classical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="214"/>
        <source>Club</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="215"/>
        <source>Dance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="216"/>
        <source>Full bass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="217"/>
        <source>Full bass and treble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="218"/>
        <source>Full treble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="219"/>
        <source>Headphones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="220"/>
        <source>Large hall</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="221"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="222"/>
        <source>Party</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="223"/>
        <source>Pop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="224"/>
        <source>Reggae</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="225"/>
        <source>Rock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="226"/>
        <source>Ska</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="227"/>
        <source>Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="228"/>
        <source>Soft rock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="229"/>
        <source>Techno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="230"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="235"/>
        <source>Use the current values as default values for new videos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="237"/>
        <source>Set all controls to zero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="252"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/audioequalizer.cpp" line="253"/>
        <source>The current values have been stored to be used as default.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BottomWidget</name>
    <message>
        <location filename="../bottomwidget.cpp" line="220"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bottomwidget.cpp" line="221"/>
        <source>Prev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bottomwidget.cpp" line="222"/>
        <source>Play / Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bottomwidget.cpp" line="223"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bottomwidget.cpp" line="224"/>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bottomwidget.cpp" line="225"/>
        <source>Play List</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../smplayer/core.cpp" line="1140"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="1153"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2502"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2527"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2550"/>
        <source>A-B markers cleared</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2898"/>
        <source>Brightness: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2914"/>
        <source>Contrast: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2929"/>
        <source>Gamma: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2944"/>
        <source>Hue: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="2959"/>
        <source>Saturation: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3013"/>
        <source>Speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3114"/>
        <source>Volume: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3178"/>
        <source>Subtitle delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3196"/>
        <source>Audio delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3253"/>
        <location filename="../smplayer/core.cpp" line="3264"/>
        <source>Font scale: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3348"/>
        <source>Subtitles on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3350"/>
        <source>Subtitles off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3826"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3874"/>
        <source>Mouse wheel seeks now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3877"/>
        <source>Mouse wheel changes volume now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3880"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3883"/>
        <source>Mouse wheel changes speed now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="3988"/>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="4202"/>
        <source>Screenshot saved as %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="4224"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="4229"/>
        <source>Buffering...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/core.cpp" line="4235"/>
        <source>Starting...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../smplayer/errordialog.ui" line="26"/>
        <location filename="../smplayer/errordialog.ui" line="64"/>
        <source>MPlayer Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/errordialog.ui" line="38"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/errordialog.ui" line="80"/>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/errordialog.ui" line="105"/>
        <source>Oops, something wrong happened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/errordialog.ui" line="130"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/errordialog.ui" line="159"/>
        <location filename="../smplayer/errordialog.cpp" line="106"/>
        <source>Show log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/errordialog.cpp" line="102"/>
        <source>Hide log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EscTip</name>
    <message>
        <location filename="../esctip.cpp" line="50"/>
        <source>Press ESC to exit full screen mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../smplayer/filechooser.cpp" line="45"/>
        <source>Click to select a file or folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="14"/>
        <source>Kylin Video - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="73"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="124"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="153"/>
        <location filename="../smplayer/filepropertiesdialog.ui" line="200"/>
        <source>&amp;Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="181"/>
        <source>&amp;Select the video codec:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="225"/>
        <source>&amp;Select the audio codec:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="244"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="259"/>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="213"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="272"/>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="211"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.ui" line="285"/>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="212"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="109"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="114"/>
        <source>Demuxer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="118"/>
        <source>Video codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/filepropertiesdialog.cpp" line="122"/>
        <source>Audio codec</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsDialog</name>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="23"/>
        <source>Select the multimedia keys that kylin-video will capture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="35"/>
        <source>Media &amp;Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="42"/>
        <source>Media &amp;Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="49"/>
        <source>Media Pre&amp;vious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="56"/>
        <source>Media &amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="63"/>
        <source>Media P&amp;ause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="97"/>
        <source>Media &amp;Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="104"/>
        <source>Volume &amp;Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="111"/>
        <source>Volume &amp;Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.ui" line="118"/>
        <source>Volume &amp;Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/globalshortcuts/globalshortcutsdialog.cpp" line="26"/>
        <source>Global Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpDialog</name>
    <message>
        <location filename="../helpdialog.ui" line="14"/>
        <source>Kylin Video - Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../helpdialog.ui" line="35"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../helpdialog.ui" line="109"/>
        <location filename="../helpdialog.cpp" line="145"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../helpdialog.cpp" line="70"/>
        <source>Supported formats</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../smplayer/inputurl.ui" line="26"/>
        <location filename="../smplayer/inputurl.ui" line="77"/>
        <source>Enter URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/inputurl.ui" line="38"/>
        <location filename="../smplayer/inputurl.cpp" line="63"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/inputurl.ui" line="51"/>
        <location filename="../smplayer/inputurl.cpp" line="68"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/inputurl.ui" line="115"/>
        <source>URL:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../smplayer/languages.cpp" line="24"/>
        <source>Afar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="25"/>
        <source>Abkhazian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="26"/>
        <source>Avestan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="27"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="28"/>
        <source>Akan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="29"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="30"/>
        <source>Aragonese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="31"/>
        <location filename="../smplayer/languages.cpp" line="297"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="32"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="33"/>
        <source>Avaric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="34"/>
        <source>Aymara</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="35"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="36"/>
        <source>Bashkir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="37"/>
        <location filename="../smplayer/languages.cpp" line="322"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="38"/>
        <location filename="../smplayer/languages.cpp" line="323"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="39"/>
        <source>Bihari</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="40"/>
        <source>Bislama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="41"/>
        <source>Bambara</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="42"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="43"/>
        <source>Tibetan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="44"/>
        <source>Breton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="45"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="46"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="47"/>
        <source>Chechen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="48"/>
        <source>Corsican</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="49"/>
        <source>Cree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="50"/>
        <location filename="../smplayer/languages.cpp" line="324"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="51"/>
        <source>Church</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="52"/>
        <source>Chuvash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="53"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="54"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="55"/>
        <location filename="../smplayer/languages.cpp" line="216"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="56"/>
        <source>Divehi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="57"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="58"/>
        <source>Ewe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="59"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="60"/>
        <location filename="../smplayer/languages.cpp" line="217"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="61"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="62"/>
        <location filename="../smplayer/languages.cpp" line="218"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="63"/>
        <location filename="../smplayer/languages.cpp" line="325"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="64"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="65"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="66"/>
        <source>Fulah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="67"/>
        <location filename="../smplayer/languages.cpp" line="219"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="68"/>
        <source>Fijian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="69"/>
        <source>Faroese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="70"/>
        <location filename="../smplayer/languages.cpp" line="220"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="71"/>
        <source>Frisian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="72"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="73"/>
        <source>Gaelic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="74"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="75"/>
        <source>Guarani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="76"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="77"/>
        <source>Manx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="78"/>
        <source>Hausa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="79"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="80"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="81"/>
        <source>Hiri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="82"/>
        <location filename="../smplayer/languages.cpp" line="326"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="83"/>
        <source>Haitian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="84"/>
        <location filename="../smplayer/languages.cpp" line="327"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="85"/>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="86"/>
        <source>Herero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="87"/>
        <source>Chamorro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="88"/>
        <source>Interlingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="89"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="90"/>
        <source>Interlingue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="91"/>
        <source>Igbo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="92"/>
        <source>Sichuan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="93"/>
        <source>Inupiaq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="94"/>
        <source>Ido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="95"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="96"/>
        <location filename="../smplayer/languages.cpp" line="221"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="97"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="98"/>
        <location filename="../smplayer/languages.cpp" line="222"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="99"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="100"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="101"/>
        <source>Kongo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="102"/>
        <source>Kikuyu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="103"/>
        <source>Kuanyama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="104"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="105"/>
        <source>Greenlandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="106"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="107"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="108"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="109"/>
        <source>Kanuri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="110"/>
        <source>Kashmiri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="111"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="112"/>
        <source>Komi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="113"/>
        <source>Cornish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="114"/>
        <source>Kirghiz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="115"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="116"/>
        <source>Luxembourgish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="117"/>
        <source>Ganda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="118"/>
        <source>Limburgan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="119"/>
        <source>Lingala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="120"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="121"/>
        <location filename="../smplayer/languages.cpp" line="328"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="122"/>
        <source>Luba-Katanga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="123"/>
        <location filename="../smplayer/languages.cpp" line="329"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="124"/>
        <source>Malagasy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="125"/>
        <source>Marshallese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="126"/>
        <source>Maori</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="127"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="128"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="129"/>
        <source>Mongolian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="130"/>
        <source>Moldavian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="131"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="132"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="133"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="134"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="135"/>
        <source>Nauru</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../smplayer/languages.cpp" line="136"/>
        <source>Bokmål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="137"/>
        <location filename="../smplayer/languages.cpp" line="143"/>
        <source>Ndebele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="138"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="139"/>
        <source>Ndonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="140"/>
        <location filename="../smplayer/languages.cpp" line="223"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="141"/>
        <source>Norwegian Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="142"/>
        <location filename="../smplayer/languages.cpp" line="224"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="144"/>
        <source>Navajo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="145"/>
        <source>Chichewa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="146"/>
        <source>Occitan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="147"/>
        <source>Ojibwa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="148"/>
        <source>Oromo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="149"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="150"/>
        <source>Ossetian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="151"/>
        <source>Panjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="152"/>
        <source>Pali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="153"/>
        <location filename="../smplayer/languages.cpp" line="330"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="154"/>
        <source>Pushto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="155"/>
        <location filename="../smplayer/languages.cpp" line="225"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="156"/>
        <source>Quechua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="157"/>
        <source>Romansh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="158"/>
        <source>Rundi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="159"/>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="160"/>
        <location filename="../smplayer/languages.cpp" line="226"/>
        <location filename="../smplayer/languages.cpp" line="304"/>
        <location filename="../smplayer/languages.cpp" line="331"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="161"/>
        <source>Kinyarwanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="162"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="163"/>
        <source>Sardinian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="164"/>
        <source>Sindhi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="165"/>
        <source>Sami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="166"/>
        <source>Sango</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="167"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="168"/>
        <location filename="../smplayer/languages.cpp" line="332"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="169"/>
        <location filename="../smplayer/languages.cpp" line="333"/>
        <source>Slovene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="170"/>
        <source>Samoan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="171"/>
        <source>Shona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="172"/>
        <source>Somali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="173"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="174"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="175"/>
        <source>Swati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="176"/>
        <source>Sotho</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="177"/>
        <source>Sundanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="178"/>
        <location filename="../smplayer/languages.cpp" line="227"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="179"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="180"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="181"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="182"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="183"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="184"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="185"/>
        <source>Turkmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="186"/>
        <source>Tagalog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="187"/>
        <source>Tswana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="188"/>
        <source>Tonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="189"/>
        <location filename="../smplayer/languages.cpp" line="299"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="190"/>
        <source>Tsonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="191"/>
        <source>Tatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="192"/>
        <source>Twi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="193"/>
        <source>Tahitian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="194"/>
        <source>Uighur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="195"/>
        <location filename="../smplayer/languages.cpp" line="334"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="196"/>
        <source>Urdu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="197"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="198"/>
        <source>Venda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="199"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../smplayer/languages.cpp" line="200"/>
        <source>Volapük</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="201"/>
        <source>Walloon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="202"/>
        <source>Wolof</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="203"/>
        <source>Xhosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="204"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="205"/>
        <source>Yoruba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="206"/>
        <source>Zhuang</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="207"/>
        <location filename="../smplayer/languages.cpp" line="228"/>
        <location filename="../smplayer/languages.cpp" line="335"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="208"/>
        <source>Zulu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="236"/>
        <source>Arabic - Syria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="289"/>
        <source>Unicode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="290"/>
        <source>UTF-8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="291"/>
        <source>Western European Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="292"/>
        <source>Western European Languages with Euro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="293"/>
        <source>Slavic/Central European Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="294"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="295"/>
        <source>Old Baltic charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="296"/>
        <source>Cyrillic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="298"/>
        <source>Modern Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="300"/>
        <source>Baltic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="301"/>
        <source>Celtic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="302"/>
        <source>South-Eastern European</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="303"/>
        <source>Hebrew charsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="305"/>
        <source>Ukrainian, Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="306"/>
        <source>Simplified Chinese charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="307"/>
        <source>Traditional Chinese charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="308"/>
        <source>Japanese charsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="309"/>
        <source>Korean charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="310"/>
        <source>Thai charset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="311"/>
        <source>Cyrillic Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="312"/>
        <source>Slavic/Central European Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="313"/>
        <source>Arabic Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/languages.cpp" line="314"/>
        <source>Modern Greek Windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LineEditWithIcon</name>
    <message>
        <location filename="../smplayer/lineedit_with_icon.cpp" line="35"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MPVProcess</name>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="190"/>
        <source>the &apos;%1&apos; filter is not supported by mpv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="879"/>
        <source>File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="882"/>
        <source>Video:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="883"/>
        <source>Resolution:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="884"/>
        <source>Frames per second:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="884"/>
        <source>Estimated:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="886"/>
        <source>Aspect Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="887"/>
        <location filename="../smplayer/mpvoptions.cpp" line="892"/>
        <source>Bitrate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="888"/>
        <source>Dropped frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="891"/>
        <source>Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="893"/>
        <source>Sample Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="894"/>
        <source>Channels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="897"/>
        <source>Audio/video synchronization:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="898"/>
        <source>Cache fill:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mpvoptions.cpp" line="899"/>
        <source>Used cache:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="149"/>
        <location filename="../mainwindow.cpp" line="1159"/>
        <source>Kylin Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="365"/>
        <source>A:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="369"/>
        <source>B:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="382"/>
        <source>Warning - Using old MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="383"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. kylin-video can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="388"/>
        <source>Please, update your MPlayer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="390"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="589"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="595"/>
        <source>Open &amp;File...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="599"/>
        <source>Directory...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="603"/>
        <source>&amp;URL...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="614"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="619"/>
        <source>Recent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="632"/>
        <source>&amp;Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="633"/>
        <source>&amp;Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="634"/>
        <source>While &amp;playing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="640"/>
        <source>S&amp;tay on top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="647"/>
        <source>Play control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="649"/>
        <source>Forward and rewind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="687"/>
        <source>&amp;Jump to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="699"/>
        <source>Play Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="720"/>
        <source>Normal speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="721"/>
        <source>Half speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="722"/>
        <source>Double speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="723"/>
        <source>Speed -10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="724"/>
        <source>Speed +10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="725"/>
        <source>Speed -4%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="726"/>
        <source>Speed +4%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="727"/>
        <source>Speed -1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="728"/>
        <source>Speed +1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="752"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="753"/>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="769"/>
        <source>Order play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="770"/>
        <source>Random play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="771"/>
        <source>List loop play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="776"/>
        <source>Play order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="801"/>
        <source>&amp;Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="812"/>
        <source>&amp;Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="818"/>
        <source>Aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="831"/>
        <source>&amp;Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="832"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="833"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="834"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="835"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="840"/>
        <source>Fli&amp;p image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="845"/>
        <source>Mirr&amp;or image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="849"/>
        <source>Frame rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="854"/>
        <source>&amp;Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <location filename="../mainwindow.cpp" line="975"/>
        <source>&amp;Stereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="873"/>
        <source>&amp;4.0 Surround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="874"/>
        <source>&amp;5.1 Surround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="875"/>
        <source>&amp;6.1 Surround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="876"/>
        <source>&amp;7.1 Surround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="881"/>
        <source>&amp;Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="884"/>
        <location filename="../mainwindow.cpp" line="949"/>
        <location filename="../mainwindow.cpp" line="2193"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>&amp;Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="911"/>
        <source>&amp;Extrastereo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="912"/>
        <source>&amp;Karaoke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="913"/>
        <source>Volume &amp;normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="914"/>
        <source>&amp;Headphone optimization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="923"/>
        <source>&amp;Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="928"/>
        <source>Volume -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="931"/>
        <source>Volume +</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="934"/>
        <source>Delay -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="937"/>
        <source>Delay +</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="940"/>
        <source>Set dela&amp;y...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="947"/>
        <location filename="../mainwindow.cpp" line="2190"/>
        <location filename="../mainwindow.cpp" line="2289"/>
        <source>Choose a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="950"/>
        <location filename="../mainwindow.cpp" line="2195"/>
        <location filename="../mainwindow.cpp" line="2292"/>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="954"/>
        <source>&amp;Load external file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="957"/>
        <source>U&amp;nload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="961"/>
        <source>E&amp;qualizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="965"/>
        <source>Reset audio equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="976"/>
        <source>&amp;Left channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="977"/>
        <source>&amp;Right channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="978"/>
        <source>&amp;Mono</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="979"/>
        <source>Re&amp;verse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="985"/>
        <source>&amp;Stereo mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1018"/>
        <source>&amp;Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1037"/>
        <location filename="../mainwindow.cpp" line="2291"/>
        <source>Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1041"/>
        <source>Load...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1046"/>
        <source>Subtitle &amp;visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1055"/>
        <source>Show &amp;info on OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1064"/>
        <source>Size &amp;+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1068"/>
        <source>Size &amp;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1072"/>
        <source>Show times with &amp;milliseconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1083"/>
        <source>Subtitles onl&amp;y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1084"/>
        <source>Volume + &amp;Seek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1085"/>
        <source>Volume + Seek + &amp;Timer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1086"/>
        <source>Volume + Seek + Timer + T&amp;otal time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1100"/>
        <source>&amp;OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1108"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1112"/>
        <source>View &amp;info and properties...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1116"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1120"/>
        <source>About &amp;Kylin Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1123"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>PlayList</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1143"/>
        <source>Play/Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1147"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1151"/>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1166"/>
        <source>Open Homepage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1169"/>
        <source>Open screenshots folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1178"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1178"/>
        <source>The screenshot folder does not exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1261"/>
        <source>Failed to add files!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1585"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1619"/>
        <location filename="../mainwindow.cpp" line="1620"/>
        <location filename="../mainwindow.cpp" line="1621"/>
        <source>-%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1623"/>
        <location filename="../mainwindow.cpp" line="1624"/>
        <location filename="../mainwindow.cpp" line="1625"/>
        <source>+%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1816"/>
        <source>&lt;empty&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2120"/>
        <source>Confirm deletion - Kylin Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2120"/>
        <source>Delete the list of recent files?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2191"/>
        <source>Multimedia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2192"/>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2194"/>
        <source>Playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2231"/>
        <source>Choose a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2382"/>
        <source>&amp;Jump to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2383"/>
        <source>Kylin Video - Seek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2411"/>
        <location filename="../mainwindow.cpp" line="2415"/>
        <source>Kylin Video - Subtitle delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2412"/>
        <location filename="../mainwindow.cpp" line="2416"/>
        <source>Subtitle delay (in milliseconds):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2530"/>
        <source>Error detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2531"/>
        <source>Unfortunately this video can&apos;t be played.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2532"/>
        <source>The server returned &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2793"/>
        <source>Jump to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3005"/>
        <location filename="../mainwindow.cpp" line="3006"/>
        <location filename="../mainwindow.cpp" line="3016"/>
        <location filename="../mainwindow.cpp" line="3017"/>
        <location filename="../mainwindow.cpp" line="3030"/>
        <location filename="../mainwindow.cpp" line="3031"/>
        <source>%1 Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3007"/>
        <source>&apos;%1&apos; was not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3018"/>
        <source>%1 has finished unexpectedly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3019"/>
        <source>Exit code: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3033"/>
        <source>%1 failed to start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3034"/>
        <source>Please check the %1 path in preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3036"/>
        <source>%1 has crashed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3037"/>
        <source>See the log for more info.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MaskWidget</name>
    <message>
        <location filename="../maskwidget.cpp" line="47"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageDialog</name>
    <message>
        <location filename="../messagedialog.cpp" line="65"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messagedialog.cpp" line="73"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messagedialog.cpp" line="81"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messagedialog.cpp" line="89"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MplayerProcess</name>
    <message>
        <location filename="../smplayer/mplayeroptions.cpp" line="403"/>
        <location filename="../smplayer/mplayeroptions.cpp" line="480"/>
        <source>This option is not supported by MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayListView</name>
    <message>
        <location filename="../playlistview.cpp" line="413"/>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistview.cpp" line="420"/>
        <source>Remove &amp;selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlistview.cpp" line="425"/>
        <source>&amp;Delete file from disk</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="297"/>
        <source>Playlist is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="302"/>
        <source>Add File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="312"/>
        <source>PlayList</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="317"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="325"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="835"/>
        <source>Choose a filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="837"/>
        <source>Playlists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="837"/>
        <location filename="../playlist.cpp" line="1099"/>
        <location filename="../playlist.cpp" line="1159"/>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="847"/>
        <source>Confirm overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="848"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1020"/>
        <source>Reached the end of the playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1096"/>
        <location filename="../playlist.cpp" line="1156"/>
        <source>Select one or more files to open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1098"/>
        <location filename="../playlist.cpp" line="1158"/>
        <source>Multimedia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1210"/>
        <source>Choose a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1283"/>
        <source>Confirm remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1284"/>
        <source>You&apos;re about to remove the file from the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1285"/>
        <location filename="../playlist.cpp" line="1430"/>
        <source>Are you sure you want to proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1354"/>
        <source>Confirm deletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1355"/>
        <source>You&apos;re about to Delete the files from your drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1356"/>
        <source>This action cannot be undone. Are you sure you want to proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1428"/>
        <source>Confirm remove all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1429"/>
        <source>You&apos;re about to empty the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PoweroffDialog</name>
    <message>
        <location filename="../poweroffdialog.cpp" line="26"/>
        <source>The computer will shut down in %1 seconds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../poweroffdialog.cpp" line="26"/>
        <source>Press &lt;b&gt;Cancel&lt;/b&gt; to abort shutdown.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../poweroffdialog.cpp" line="87"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../poweroffdialog.cpp" line="95"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefAudio</name>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="26"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="44"/>
        <location filename="../smplayer/prefaudio.cpp" line="316"/>
        <source>Global volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="68"/>
        <source>Use software volume control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="91"/>
        <source>Max. Amplification:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="119"/>
        <location filename="../smplayer/prefaudio.cpp" line="333"/>
        <source>Volume normalization by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="135"/>
        <source>Synchronization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="155"/>
        <location filename="../smplayer/prefaudio.cpp" line="336"/>
        <source>Audio/video auto synchronization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="181"/>
        <source>Factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="227"/>
        <source>Output driver:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.ui" line="293"/>
        <source>Channels by default:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="88"/>
        <location filename="../smplayer/prefaudio.cpp" line="150"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="89"/>
        <source>2 (Stereo)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="90"/>
        <source>4 (4.0 Surround)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="91"/>
        <source>6 (5.1 Surround)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="92"/>
        <source>7 (6.1 Surround)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="93"/>
        <source>8 (7.1 Surround)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="295"/>
        <source>Audio output driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="296"/>
        <source>Select the audio output driver.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="298"/>
        <source>%1 is the recommended one. Try to avoid %2 and %3, they are slow and can have an impact on performance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="305"/>
        <source>Channels by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="306"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="317"/>
        <source>If this option is checked, the same volume will be used for all files you play. If the option is not checked each file uses its own volume.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="320"/>
        <source>This option also applies for the mute control.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="322"/>
        <source>Software volume control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="323"/>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="326"/>
        <source>Max. Amplification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="327"/>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="334"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefaudio.cpp" line="337"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../smplayer/prefgeneral.ui" line="26"/>
        <location filename="../smplayer/prefgeneral.cpp" line="140"/>
        <source>Pause when minimized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.ui" line="39"/>
        <source>MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.ui" line="52"/>
        <source>MPV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.ui" line="65"/>
        <source>Playback engine:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.ui" line="81"/>
        <source>Preview when video is playing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="141"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="144"/>
        <source>Preview when the video is playing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="145"/>
        <source>If this option is enabled, the video preview will be displayed when the mouse is placed on the progress bar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="147"/>
        <source>Select MPlayer as playback engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="148"/>
        <source>If you change the playback engine to MPlayer, please restart Kylin Video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="149"/>
        <source>Select MPV as playback engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefgeneral.cpp" line="150"/>
        <source>If you change the playback engine to MPV, please restart Kylin Video.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="26"/>
        <location filename="../smplayer/prefperformance.cpp" line="156"/>
        <source>Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="49"/>
        <source>Cache for local files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="66"/>
        <location filename="../smplayer/prefperformance.ui" line="94"/>
        <source>KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="77"/>
        <source>Cache for streams:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="112"/>
        <source>Decode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="135"/>
        <source>Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.ui" line="172"/>
        <location filename="../smplayer/prefperformance.cpp" line="140"/>
        <source>Hardware decoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="32"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="33"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="52"/>
        <location filename="../smplayer/prefperformance.cpp" line="134"/>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="136"/>
        <source>Threads for decoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="137"/>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="141"/>
        <source>Sets the hardware video decoding API. If hardware decoding is not possible, software decoding will be used instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="143"/>
        <source>Available options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="145"/>
        <source>None: only software decoding will be used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="146"/>
        <source>Auto: it tries to automatically enable hardware decoding using the first available method.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="148"/>
        <source>vdpau: for the vdpau and opengl video outputs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="149"/>
        <source>vaapi: for the opengl and vaapi video outputs. For Intel GPUs only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="150"/>
        <source>vaapi-copy: it copies video back into system RAM. For Intel GPUs only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="154"/>
        <source>This option only works with mpv.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="158"/>
        <source>Cache for files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="159"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="162"/>
        <source>Cache for streams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefperformance.cpp" line="163"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefScreenShot</name>
    <message>
        <location filename="../smplayer/prefscreenshot.ui" line="26"/>
        <source>Screenshots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.ui" line="32"/>
        <location filename="../smplayer/prefscreenshot.cpp" line="144"/>
        <source>Enable screenshots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.ui" line="44"/>
        <source>Folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.ui" line="71"/>
        <source>Template:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.ui" line="91"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="71"/>
        <source>Select a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="145"/>
        <source>You can use this option to enable or disable the possibility to take screenshots.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="148"/>
        <source>Screenshots folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="149"/>
        <source>Here you can specify a folder where the screenshots taken by Kylin Video will be stored. If the folder is not valid the screenshot feature will be disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="153"/>
        <source>Template for screenshots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="154"/>
        <source>This option specifies the filename template used to save screenshots.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="155"/>
        <source>For example %1 would save the screenshot as &apos;moviename_0001.png&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="156"/>
        <source>%1 specifies the filename of the video without the extension, %2 adds a 4 digit number padded with zeros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="158"/>
        <source>For a full list of the template specifiers visit this link:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="161"/>
        <location filename="../smplayer/prefscreenshot.cpp" line="165"/>
        <source>This option only works with mpv.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="163"/>
        <source>Format for screenshots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefscreenshot.cpp" line="164"/>
        <source>This option allows one to choose the image file type used for saving screenshots.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefShortCut</name>
    <message>
        <location filename="../smplayer/prefshortcut.ui" line="50"/>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefshortcut.cpp" line="36"/>
        <source>ShortCut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefshortcut.cpp" line="48"/>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefshortcut.cpp" line="66"/>
        <source>Shortcut Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefshortcut.cpp" line="68"/>
        <source>Shortcut editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefshortcut.cpp" line="69"/>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="26"/>
        <location filename="../smplayer/prefsubtitles.cpp" line="154"/>
        <source>Autoload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="63"/>
        <source>Autoload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="77"/>
        <source>Same name as movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="82"/>
        <source>All subs containing movie name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="87"/>
        <source>All subs in directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="104"/>
        <source>Encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="127"/>
        <source>Default subtitle encoding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.ui" line="176"/>
        <source>Try to autodetect for this language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="47"/>
        <location filename="../smplayer/prefsubtitles.cpp" line="152"/>
        <source>Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="155"/>
        <source>Select the subtitle autoload method.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="157"/>
        <source>Default subtitle encoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="158"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="161"/>
        <source>Try to autodetect for this language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="162"/>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a MPlayer compiled with ENCA support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="168"/>
        <source>Subtitle language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="169"/>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefsubtitles.cpp" line="172"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefVideo</name>
    <message>
        <location filename="../smplayer/prefvideo.ui" line="26"/>
        <location filename="../smplayer/prefvideo.cpp" line="265"/>
        <source>Enable postprocessing by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.ui" line="39"/>
        <location filename="../smplayer/prefvideo.cpp" line="284"/>
        <source>Draw video using slices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.ui" line="52"/>
        <location filename="../smplayer/prefvideo.cpp" line="274"/>
        <source>Direct rendering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.ui" line="65"/>
        <location filename="../smplayer/prefvideo.cpp" line="279"/>
        <source>Double buffering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.ui" line="78"/>
        <source>Use software video equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.ui" line="110"/>
        <source>Output driver:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="125"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="130"/>
        <source>slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="260"/>
        <source>Video output driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="261"/>
        <source>Select the video output driver. %1 provides the best performance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="266"/>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="268"/>
        <source>Software video equalizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="269"/>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="275"/>
        <source>If checked, turns on direct rendering (not supported by all codecs and video outputs)&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; May cause OSD/SUB corruption!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="280"/>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/prefvideo.cpp" line="285"/>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../smplayer/preferencesdialog.ui" line="14"/>
        <source>Kylin Video - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.ui" line="35"/>
        <source>Preference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.ui" line="109"/>
        <location filename="../smplayer/preferencesdialog.cpp" line="235"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.ui" line="122"/>
        <location filename="../smplayer/preferencesdialog.cpp" line="236"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.ui" line="135"/>
        <location filename="../smplayer/preferencesdialog.cpp" line="234"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="85"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="93"/>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="100"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="107"/>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="114"/>
        <source>Subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="121"/>
        <source>ScreenShot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/preferencesdialog.cpp" line="128"/>
        <source>Shortcut Key</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../kylinvideo.cpp" line="276"/>
        <source>This is Kylin Vedio v. %1 running on %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mediasettings.cpp" line="185"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mediasettings.cpp" line="196"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/mediasettings.cpp" line="197"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../utils.cpp" line="78"/>
        <location filename="../utils.cpp" line="85"/>
        <source>%n second(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../utils.cpp" line="82"/>
        <location filename="../utils.cpp" line="84"/>
        <source>%n minute(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="86"/>
        <source>%1 and %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="277"/>
        <source>Modify shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="302"/>
        <source>Add shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="310"/>
        <source>Remove shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="329"/>
        <source>Press the key combination you want to assign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="350"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="356"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="361"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="363"/>
        <source>Capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/shortcutgetter.cpp" line="366"/>
        <source>Capture keystrokes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SupportFormats</name>
    <message>
        <location filename="../supportformats.ui" line="26"/>
        <source>Video formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../supportformats.ui" line="52"/>
        <source>Audio formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../supportformats.ui" line="78"/>
        <source>Subtitles formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../supportformats.cpp" line="52"/>
        <source>Some video formats do not support preview and seek by dragging, e.g. the swf.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../smplayer/timedialog.ui" line="26"/>
        <location filename="../smplayer/timedialog.ui" line="77"/>
        <source>Seek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/timedialog.ui" line="38"/>
        <location filename="../smplayer/timedialog.cpp" line="51"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/timedialog.ui" line="51"/>
        <location filename="../smplayer/timedialog.cpp" line="56"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/timedialog.ui" line="99"/>
        <source>Jump to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../titlewidget.cpp" line="118"/>
        <source>Kylin Video</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../smplayer/tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../smplayer/videopreview.cpp" line="131"/>
        <source>The length of the video is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/videopreview.cpp" line="140"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/videopreview.cpp" line="161"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/videopreview.cpp" line="270"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/videopreview.cpp" line="300"/>
        <source>No filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer/videopreview.cpp" line="395"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
